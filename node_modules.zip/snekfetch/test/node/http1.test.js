/**
 * @jest-environment node
 */

global.HTTP_VERSION = 1;

require('./main');
